package com.example.demo.rest;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.DataModel;
import com.example.demo.service.FetchDataService;


@RestController
public class ReadFileController {
	
	@Autowired
	private FetchDataService fetchDataServiceImpl;

	private static final Logger LOGGER=LoggerFactory.getLogger(ReadFileController.class);

	@RequestMapping(path = "/viewData", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<DataModel> checkReady(@RequestParam(value = "sort", required = false) String sort) throws IOException {
		LOGGER.info("viewData API Called");
		if (sort==null)
			sort="asc";
		return fetchDataServiceImpl.getdDataFromFile("datasource/studentData.xlsx", sort);
	}
}
