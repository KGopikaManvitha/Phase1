package com.example.demo.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.example.demo.model.DataModel;
import com.example.demo.service.FetchDataService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class FetchDataServiceImpl implements FetchDataService {
	
	private static final Logger LOGGER=LoggerFactory.getLogger(FetchDataServiceImpl.class);

	@Override
	public List<DataModel> getdDataFromFile(String filePath, String sort) throws IOException {
		List<DataModel> responseList = new ArrayList<>();
		try {
			FileInputStream file = new FileInputStream(new File("datasource/studentData.xlsx"));
			Workbook workbook = new XSSFWorkbook(filePath);
			Sheet sheet = workbook.getSheetAt(0);

			int i = 0;
			for (Row row : sheet) {
				if(i==0) {
					i++;
					continue;
				}
				DataModel rowData = new DataModel();
				if(row.getCell(0)!=null) {
					rowData.setName(row.getCell(0).toString());
					rowData.setPlace(row.getCell(1).toString());
					responseList.add(rowData);
				}
				i++;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(sort.equals("asc"))
			Collections.sort(responseList, (o1, o2) -> (o1.getName().compareTo(o2.getName())));
		else
			Collections.sort(responseList, (o1, o2) -> (o2.getName().compareTo(o1.getName())));

		return responseList;
	}
}
