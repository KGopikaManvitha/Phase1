package com.example.demo.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.example.demo.model.DataModel;

public interface FetchDataService {

	List<DataModel> getdDataFromFile(String filePath, String sort) throws IOException;

}
