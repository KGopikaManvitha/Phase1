package com.example.demo.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface FetchDataService {

	Map<Integer, List<String>> getdDataFromFile(String filePath) throws IOException;

}
