package com.example.demo.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.example.demo.service.FetchDataService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class FetchDataServiceImpl implements FetchDataService {
	
	private static final Logger LOGGER=LoggerFactory.getLogger(FetchDataServiceImpl.class);

	@Override
	public Map<Integer, List<String>> getdDataFromFile(String filePath) throws IOException {
	    String response = "";
		Map<Integer, List<String>> data = new HashMap<>();
		try {
			FileInputStream file = new FileInputStream(new File("datasource/studentData.xlsx"));
			Workbook workbook = new XSSFWorkbook(filePath);
			Sheet sheet = workbook.getSheetAt(0);

			int i = 0;
			for (Row row : sheet) {
				data.put(i, new ArrayList<String>());
				response+="\n";
				for (Cell cell : row) {
					switch (cell.getCellType()) {
					case STRING:
						if(!cell.toString().trim().isEmpty()) {
							data.get(new Integer(i)).add(cell.toString());
							response+=cell.toString()+",";
						}
						break;
					default:
						LOGGER.info("invalide data found");
					}
				}
				if(data.get(new Integer(i)).isEmpty()) {
					data.remove(i);
				}
				i++;
			}
			LOGGER.info(response);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}
}
