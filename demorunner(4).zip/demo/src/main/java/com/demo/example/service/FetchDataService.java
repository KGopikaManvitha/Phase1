package com.demo.example.service;

import java.util.List;
import java.util.Map;

public interface FetchDataService {

	Map<String, List<String>> getdDataFromFile(String filePath);

}
